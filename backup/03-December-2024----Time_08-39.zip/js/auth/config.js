
// # config.js
const firebaseConfig = {
    apiKey: "AIzaSyBlEgUlhRXpVdb6Zi4z7y1uKl1wuO88dyE",
    authDomain: "os-2904.firebaseapp.com",
    projectId: "os-2904",
    storageBucket: "os-2904.firebasestorage.app",
    messagingSenderId: "565295518976",
    appId: "1:565295518976:web:c8cf9b4ae446a2e2c78fe5",
    measurementId: "G-YMWV8N4JEK"
};
