export class AnimationManager {
    static CONFIG = {
        ANIMATION: {
            DEFAULT_DURATION: 250,
            FPS: 60,
            ZOOM_THRESHOLDS: {
                WORLD_VIEW: 2
            }
        },
        OPACITY: {
            FADEOUT: {
                MIN: 0.3,
                MAX: 0.4,
                BASE: 0.4,
                STEP: 0.02
            },
            FADEIN: {
                MIN: 0.45,
                MAX: 0.85,
                BASE: 0.45,
                STEP: 0.05
            }
        },
        EASING: {
            linear: t => t,
            easeInOutCubic: t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
        }
    };

    constructor() {
        this.activeAnimations = new Map();
        this.animationFrameId = null;
        this.lastFrameTime = 0;
        
        // Bind methods
        this.updateAnimations = this.updateAnimations.bind(this);
        
        // Initialize performance optimization properties
        this.frameInterval = 1000 / AnimationManager.CONFIG.ANIMATION.FPS;
    }

    handleZoomAnimations(currentZoomLevel, uiElements) {
        const { ANIMATION, OPACITY } = AnimationManager.CONFIG;
        const { worldLevelText, compulsoryDebugData, headerAndFooter } = uiElements;

        // Cancel any ongoing animations
        this.cancelActiveAnimations();

        if (currentZoomLevel < ANIMATION.ZOOM_THRESHOLDS.WORLD_VIEW) {
            this.handleWorldViewAnimations(uiElements);
        } else {
            this.handleDetailedViewAnimations(currentZoomLevel, uiElements);
        }
    }

    handleWorldViewAnimations(uiElements) {
        const { worldLevelText, compulsoryDebugData, headerAndFooter } = uiElements;
        
        this.startFadeAnimation(worldLevelText, 1, undefined, 'element');
        this.startFadeAnimation(compulsoryDebugData.parent, 0, undefined, 'element');
        this.startFadeAnimation(headerAndFooter.header, 0.45, undefined, 'background');
        this.startFadeAnimation(headerAndFooter.footer, 0.45, undefined, 'background');
    }

    handleDetailedViewAnimations(currentZoomLevel, uiElements) {
        const { OPACITY } = AnimationManager.CONFIG;
        const { worldLevelText, compulsoryDebugData, headerAndFooter } = uiElements;

        const fadeoutOpacity = this.calculateFadeoutOpacity(currentZoomLevel);
        const fadeinOpacity = this.calculateFadeinOpacity(currentZoomLevel);

        this.startFadeAnimation(headerAndFooter.header, fadeoutOpacity, undefined, 'background');
        this.startFadeAnimation(headerAndFooter.footer, fadeoutOpacity, undefined, 'background');
        this.startFadeAnimation(compulsoryDebugData.parent, fadeinOpacity, undefined, 'element');
        this.startFadeAnimation(worldLevelText, 0, undefined, 'element');
    }

    calculateFadeoutOpacity(zoomLevel) {
        const { OPACITY } = AnimationManager.CONFIG;
        const value = OPACITY.FADEOUT.BASE - 
                     this.calculateZoomStep(zoomLevel, OPACITY.FADEOUT.STEP);
        return this.clamp(value, OPACITY.FADEOUT.MIN, OPACITY.FADEOUT.MAX);
    }

    calculateFadeinOpacity(zoomLevel) {
        const { OPACITY } = AnimationManager.CONFIG;
        const value = OPACITY.FADEIN.BASE + 
                     this.calculateZoomStep(zoomLevel, OPACITY.FADEIN.STEP);
        return this.clamp(value, OPACITY.FADEIN.MIN, OPACITY.FADEIN.MAX);
    }

    startFadeAnimation(element, targetOpacity, duration = AnimationManager.CONFIG.ANIMATION.DEFAULT_DURATION, type = 'element') {
        if (!element) return;

        const startOpacity = type === 'background' 
            ? this.getBackgroundOpacity(element)
            : parseFloat(getComputedStyle(element).opacity);

        const startTime = performance.now();
        const animationId = Symbol('animation');

        this.activeAnimations.set(animationId, {
            element,
            startOpacity,
            targetOpacity,
            startTime,
            duration,
            type,
            easingFunction: AnimationManager.CONFIG.EASING.easeInOutCubic
        });

        if (!this.animationFrameId) {
            this.lastFrameTime = performance.now();
            this.animationFrameId = requestAnimationFrame(this.updateAnimations);
        }

        return animationId;
    }

    getBackgroundOpacity(element) {
        const backgroundColor = getComputedStyle(element).backgroundColor;
        const match = backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/);
        if (!match) return 1;
        return match[4] === undefined ? 1 : parseFloat(match[4]);
    }

    updateAnimations(currentTime) {
        if (currentTime - this.lastFrameTime < this.frameInterval) {
            this.animationFrameId = requestAnimationFrame(this.updateAnimations);
            return;
        }

        this.lastFrameTime = currentTime;
        const completedAnimations = new Set();

        for (const [id, animation] of this.activeAnimations) {
            const elapsed = currentTime - animation.startTime;
            const progress = Math.min(elapsed / animation.duration, 1);
            
            const easedProgress = animation.easingFunction(progress);
            const currentOpacity = animation.startOpacity + 
                                 (animation.targetOpacity - animation.startOpacity) * easedProgress;
            
            if (animation.type === 'background') {
                // Update background color opacity while keeping the RGB values
                const currentStyle = getComputedStyle(animation.element);
                const bgColor = currentStyle.backgroundColor;
                const match = bgColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*[0-9.]+)?\)/);
                
                if (match) {
                    const [_, r, g, b] = match;
                    animation.element.style.backgroundColor = `rgba(${r}, ${g}, ${b}, ${currentOpacity})`;
                }
            } else {
                animation.element.style.opacity = currentOpacity;
            }

            if (progress >= 1) {
                completedAnimations.add(id);
            }
        }

        // Cleanup completed animations
        completedAnimations.forEach(id => this.activeAnimations.delete(id));

        // Continue animation loop if there are active animations
        if (this.activeAnimations.size > 0) {
            this.animationFrameId = requestAnimationFrame(this.updateAnimations);
        } else {
            this.animationFrameId = null;
        }
    }

    cancelActiveAnimations() {
        this.activeAnimations.clear();
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
    }

    calculateZoomStep(currentZoomLevel, stepHeight, compensation = 0) {
        return stepHeight * currentZoomLevel - compensation;
    }

    clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }

    // Cleanup method
    dispose() {
        this.cancelActiveAnimations();
        this.activeAnimations = null;
    }
}