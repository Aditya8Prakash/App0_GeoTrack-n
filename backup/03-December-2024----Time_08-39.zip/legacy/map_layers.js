const MAP_TILE_DATA  = { 
    morning : {

    },
    day : {

    }, 
    evening : {

    },
    night : {
        
    }
}