export class CrosshairManager {
    constructor(map) {
        this.map = map;
        this.crosshair = document.getElementById('crosshair');
        this.centerDot = document.getElementById('centerDot');
        this.crosshairStyles = null;
        this.currentStyleIndex = 0;
        
        // Configuration constants
        this.CONFIG = {
            BASE_SIZE: 16,
            MAX_SIZE: 64,
            ZOOM_THRESHOLD: 15,
            TRANSITION_DURATION: 300,
            COLORS: {
                DEFAULT: 'rgba(255, 255, 255, 0.4)',
                TARGET: 'rgb(0, 255, 0)',
                HOVER: 'rgba(100, 181, 246, 0.5)'
            }
        };

        this.init();
    }

    async init() {
        await this.loadCrosshairStyles();
        this.setupEventListeners();
        this.updatePosition();
        // Initialize with visible crosshair
        this.showCrosshair();
    }

    async loadCrosshairStyles() {
        try {
            const response = await fetch('./json/crosshair.json');
            if (!response.ok) throw new Error('Failed to load crosshair styles');
            this.crosshairStyles = await response.json();
            this.applyCurrentStyle();
        } catch (error) {
            console.error('Crosshair styles loading error:', error);
            // Fallback to default style
            this.applyDefaultStyle();
        }
    }

    setupEventListeners() {
        // Use throttle for performance-critical events
        this.map.on('zoom', this.throttle(() => {
            this.updateCrosshairStyle();
        }, 16));

        window.addEventListener('resize', this.throttle(() => {
            this.updatePosition();
        }, 100));

        // Event delegation for style changes
        document.addEventListener('change', (e) => {
            if (e.target.name === 'crosshair_style') {
                this.currentStyleIndex = parseInt(e.target.value);
                this.applyCurrentStyle();
            }
        });
    }

    showCrosshair() {
        this.crosshair.style.opacity = '1';
        this.crosshair.style.transform = 'scale(1) translate(-50%, -50%)';
        this.crosshair.style.display = 'block';
    }

    applyCurrentStyle() {
        if (!this.crosshairStyles) return;
        
        const style = this.crosshairStyles[this.currentStyleIndex].styles;
        this.crosshair.className = `crosshair-${style.shape}`;
        
        if (!this.centerDot) {
            this.centerDot = document.createElement('div');
            this.centerDot.id = 'centerDot';
            this.centerDot.className = 'center-dot';
            this.crosshair.appendChild(this.centerDot);
        }

        this.applyBaseStyles(style);
        // Ensure crosshair remains visible after style changes
        this.showCrosshair();
    }

    applyDefaultStyle() {
        this.crosshair.className = 'crosshair-circle';
        this.crosshair.style.cssText = `
            width: ${this.CONFIG.BASE_SIZE}px;
            height: ${this.CONFIG.BASE_SIZE}px;
            border: 2px solid ${this.CONFIG.COLORS.DEFAULT};
        `;
        // Ensure crosshair remains visible with default style
        this.showCrosshair();
    }

    // Rest of the methods remain the same...
    applyBaseStyles(style) {
        const size = parseInt(style.size);
        this.crosshair.style.width = `${size}px`;
        this.crosshair.style.height = `${size}px`;
    }

    updatePosition() {
        requestAnimationFrame(() => {
            this.crosshair.style.left = '50%';
            this.crosshair.style.top = '50%';
        });
    }

    updateCrosshairStyle() {
        const currentZoom = this.map.getZoom();
        if (currentZoom < this.CONFIG.ZOOM_THRESHOLD) {
            this.applyCurrentStyle();
            return;
        }

        const style = this.crosshairStyles[this.currentStyleIndex].styles;
        const zoomDiff = currentZoom - this.CONFIG.ZOOM_THRESHOLD;
        const sizeInterpolation = Math.min(zoomDiff / 3, 1);
        const colorInterpolation = Math.min(zoomDiff / 4, 1);
        
        this.updateSize(style, sizeInterpolation);
        this.updateColors(style, colorInterpolation);
        this.updateGlow(zoomDiff, colorInterpolation);
    }

    updateSize(style, interpolation) {
        const baseSize = parseInt(this.CONFIG.BASE_SIZE);
        const newSize = baseSize + (this.CONFIG.MAX_SIZE - baseSize) * interpolation;

        if (newSize > this.CONFIG.BASE_SIZE) {
            this.crosshair.style.width = `${newSize}px`;
            this.crosshair.style.height = `${newSize}px`;
        } else {
            this.crosshair.style.width = `${this.CONFIG.BASE_SIZE}px`;
            this.crosshair.style.height = `${this.CONFIG.BASE_SIZE}px`;
        }
    }

    updateColors(style, interpolation) {
        const color = this.interpolateColor(
            this.CONFIG.COLORS.DEFAULT,
            this.CONFIG.COLORS.TARGET,
            interpolation
        );

        if (style.shape === 'circle') {
            this.crosshair.style.borderColor = color;
        } else {
            const lines = this.crosshair.querySelectorAll('::before, ::after');
            lines.forEach(line => line.style.background = color);
        }
    }

    updateGlow(zoomDiff, interpolation) {
        const glowIntensity = Math.min(zoomDiff * 2, 8);
        const shadowSize = glowIntensity * interpolation;
        this.crosshair.style.boxShadow = `
            0 0 ${shadowSize}px ${shadowSize}px rgba(0, 255, 0, ${interpolation * 0.4}),
            inset 0 0 ${shadowSize}px ${shadowSize}px rgba(0, 255, 0, ${interpolation * 0.3})
        `;
    }

    interpolateColor(startColor, endColor, progress) {
        const start = this.parseColor(startColor);
        const end = this.parseColor(endColor);
        
        if (!start || !end) return startColor;
        
        const r = Math.round(start.r + (end.r - start.r) * progress);
        const g = Math.round(start.g + (end.g - start.g) * progress);
        const b = Math.round(start.b + (end.b - start.b) * progress);
        const a = start.a + (end.a - start.a) * progress;
        
        return `rgba(${r}, ${g}, ${b}, ${a})`;
    }

    parseColor(color) {
        const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/);
        if (!match) return null;
        
        return {
            r: parseInt(match[1]),
            g: parseInt(match[2]),
            b: parseInt(match[3]),
            a: match[4] ? parseFloat(match[4]) : 1
        };
    }

    throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
}